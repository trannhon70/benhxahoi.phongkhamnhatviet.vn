<?php
// define("DB_HOST", "localhost");
// define("DB_USER", "root");
// define("DB_PASS", "");
// define("DB_NAME", "phongkhamdakhanhatviet.vn");


define("DB_HOST", "localhost");
define("DB_USER", "benh_xahoi_root");
define("DB_PASS", "Ie@giB4+inp8oH^A");
define("DB_NAME", "benh_xh_phongkhamdakhoanhatviet");   
?>