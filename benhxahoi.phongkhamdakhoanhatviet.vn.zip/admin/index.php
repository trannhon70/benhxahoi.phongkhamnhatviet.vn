<?php include 'inc/header.php'; ?>
<div class="text-center">
    <h1> Chào mừng bạn đến với Admin! </h1>
</div>

<?php include 'inc/footer.php'; ?>